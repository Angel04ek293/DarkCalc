package com.angel.darkcalc

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 16, 20)
    private val panel = Color.rgb(27, 27, 34)
    private val key = Color.rgb(43, 43, 53)
    private val accent = Color.rgb(139, 92, 246)
    private val textColor = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(165, 165, 180)
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private lateinit var historyButton: Button
    private var expression = ""
    private val history = mutableListOf<String>()
    private val prefs by lazy { getSharedPreferences("darkcalc", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        history.addAll(prefs.getStringSet("history", emptySet()).orEmpty().toList().sortedByDescending { it.substringBefore("|").toLongOrNull() ?: 0L })
        buildUi()
        updateDisplay()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "DarkCalc"
            textSize = 22f
            setTextColor(textColor)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        historyButton = Button(this).apply {
            text = "HISTORY"
            textSize = 11f
            setTextColor(Color.rgb(210, 195, 255))
            background = rounded(accent, 14)
            setOnClickListener { showHistory() }
            isAllCaps = false
        }
        header.addView(historyButton, LinearLayout.LayoutParams(dp(104), dp(42)))
        root.addView(header)

        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 22)
        }
        expressionView = TextView(this).apply {
            textSize = 24f
            setTextColor(muted)
            gravity = Gravity.END
            maxLines = 2
        }
        resultView = TextView(this).apply {
            text = "0"
            textSize = 42f
            setTextColor(textColor)
            gravity = Gravity.END
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxLines = 1
        }
        display.addView(expressionView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(resultView, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 1.1f).apply { topMargin = dp(16); bottomMargin = dp(16) })

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("±", "0", ".", "=")
        )
        val keypad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { row ->
            val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { label ->
                val b = Button(this).apply {
                    text = label
                    textSize = if (label.length > 1) 17f else 21f
                    isAllCaps = false
                    setTextColor(if (label in listOf("÷", "×", "−", "+", "=")) Color.WHITE else textColor)
                    background = rounded(if (label == "=") accent else if (label in listOf("AC", "⌫", "%", "±")) Color.rgb(57, 53, 70) else key, 18)
                    stateListAnimator = null
                    setOnClickListener { onKey(label) }
                }
                rowLayout.addView(b, LinearLayout.LayoutParams(0, 0, 1f).apply {
                    width = 0
                    height = dp(62)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            keypad.addView(rowLayout)
        }
        root.addView(keypad, LinearLayout.LayoutParams(-1, 0, 2.7f))
        setContentView(root)
    }

    private fun onKey(value: String) {
        when (value) {
            "AC" -> expression = ""
            "⌫" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
            "=" -> calculate()
            "±" -> {
                val lastNumber = Regex("(\\d*\\.?\\d+)$").find(expression)
                if (lastNumber != null) {
                    val token = lastNumber.value
                    val start = lastNumber.range.first
                    expression = expression.substring(0, start) + if (start > 0 && expression[start - 1] == '−') token else "−$token"
                } else if (expression.isEmpty()) expression = "−"
            }
            "%" -> {
                val match = Regex("(\\d*\\.?\\d+)$").find(expression)
                if (match != null) {
                    val number = match.value.toDoubleOrNull()
                    if (number != null) expression = expression.substring(0, match.range.first) + (number / 100.0).toString()
                }
            }
            else -> {
                val symbol = when (value) { "÷" -> "/"; "×" -> "*"; "−" -> "-"; else -> value }
                if (symbol in listOf("+", "-", "*", "/")) {
                    if (expression.isEmpty() && symbol != "-") return
                    if (expression.isNotEmpty() && expression.last() in listOf('+', '-', '*', '/')) expression = expression.dropLast(1)
                }
                if (symbol == ".") {
                    val current = expression.takeLastWhile { it.isDigit() || it == '.' }
                    if (current.contains('.')) return
                    if (current.isEmpty()) expression += "0"
                }
                expression += symbol
            }
        }
        updateDisplay()
    }

    private fun calculate() {
        if (expression.isBlank()) return
        try {
            val value = ExpressionParser(expression).parse()
            val formatted = formatNumber(value)
            val item = "${System.currentTimeMillis()}|$expression=$formatted"
            history.removeAll { it.substringAfter('|') == item.substringAfter('|') }
            history.add(0, item)
            while (history.size > 50) history.removeAt(history.lastIndex)
            prefs.edit().putStringSet("history", history.toSet()).apply()
            expression = formatted
            updateDisplay()
        } catch (_: Exception) {
            Toast.makeText(this, "Проверь выражение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateDisplay() {
        expressionView.text = expression.replace("*", "×").replace("/", "÷").replace("-", "−")
        resultView.text = if (expression.isEmpty()) "0" else expressionView.text
    }

    private fun showHistory() {
        if (history.isEmpty()) {
            AlertDialog.Builder(this).setTitle("История вычислений").setMessage("Пока вычислений нет.")
                .setPositiveButton("ОК", null).show()
            return
        }
        val lines = history.map { it.substringAfter('|') }.toTypedArray()
        AlertDialog.Builder(this).setTitle("История вычислений")
            .setItems(lines) { _, which ->
                val selected = history[which].substringAfter('|').substringAfter('=')
                expression = selected
                updateDisplay()
            }
            .setNeutralButton("Очистить") { _, _ ->
                history.clear()
                prefs.edit().remove("history").apply()
                Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun formatNumber(value: Double): String {
        if (!value.isFinite()) throw ArithmeticException("Invalid result")
        if (value == 0.0) return "0"
        val rounded = if (kotlin.math.abs(value) < 1e15) DecimalFormat("0.##########", DecimalFormatSymbols(Locale.US)).format(value) else value.toString()
        return rounded
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private class ExpressionParser(private val input: String) {
        private var pos = 0
        fun parse(): Double {
            val result = expression()
            skipSpaces()
            if (pos != input.length) error("Unexpected character")
            return result
        }
        private fun expression(): Double {
            var value = term()
            while (true) {
                skipSpaces()
                value = when {
                    eat('+') -> value + term()
                    eat('-') -> value - term()
                    else -> return value
                }
            }
        }
        private fun term(): Double {
            var value = factor()
            while (true) {
                skipSpaces()
                value = when {
                    eat('*') -> value * factor()
                    eat('/') -> {
                        val divisor = factor()
                        if (divisor == 0.0) error("Division by zero")
                        value / divisor
                    }
                    else -> return value
                }
            }
        }
        private fun factor(): Double {
            skipSpaces()
            if (eat('+')) return factor()
            if (eat('-')) return -factor()
            if (eat('(')) {
                val value = expression()
                skipSpaces()
                if (!eat(')')) error("Missing )")
                return value
            }
            val start = pos
            var dots = 0
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
                if (input[pos] == '.') dots++
                if (dots > 1) error("Invalid number")
                pos++
            }
            if (start == pos) error("Number expected")
            return input.substring(start, pos).toDouble()
        }
        private fun eat(c: Char): Boolean {
            if (pos < input.length && input[pos] == c) { pos++; return true }
            return false
        }
        private fun skipSpaces() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
    }
}
