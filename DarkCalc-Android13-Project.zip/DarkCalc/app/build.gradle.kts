plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.angel.darkcalc"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.angel.darkcalc"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
