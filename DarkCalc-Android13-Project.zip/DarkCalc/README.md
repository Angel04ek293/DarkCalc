# DarkCalc — Android calculator

A small dark-themed Android calculator with basic arithmetic and locally stored calculation history. It works offline and does not request network or storage permissions.

## Features
- Addition, subtraction, multiplication, division, decimals and parentheses in typed expressions
- Operator precedence and unary minus
- Percent shortcut for the last number
- Up to 50 recent calculations saved locally on the device
- Tap an item in history to reuse its result; clear history from the history dialog
- Dark UI, no internet access required

## Build an APK

### Option A: Android Studio (recommended)
1. Install Android Studio and the Android SDK (API 35 or newer).
2. Extract this project ZIP.
3. In Android Studio, choose **Open** and select the `DarkCalc` folder (the one containing `settings.gradle.kts`).
4. Let Gradle sync complete. If Android Studio asks to install a compatible SDK or Android Gradle Plugin, accept the suggested installation.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When the build finishes, choose **Locate**. The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to the Android 13 phone, open it, and allow installation from that source if Android asks.

### Option B: command line
Install JDK 17, Android Studio/Android SDK, and Gradle 8.9 or a compatible Gradle 8.x version. From this directory run:

```bash
gradle assembleDebug
```

The debug APK should be generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The project targets Android 13-compatible devices (min SDK 23, target SDK 33) and compiles with SDK 35.
- No Gradle wrapper is included, so use Android Studio's Gradle integration or an installed Gradle 8.x.
- The APK is not prebuilt in this archive; build it using the steps above.
